
const base_url="http://localhost:5454"

module.exports={base_url}