
const base_url="http://185.44.114.245:5454"

module.exports={base_url}